#include <iostream>
using namespace std;
main(){
string pais="";	
cout<<"Ingrese Pais:";
cin>>pais;

	if (pais=="guatemala"){
		cout<<"Tu eres del Mejor Pais del Mundo "<<pais<<endl;
	}else{
		cout<<"Tu eres de "<<pais<<endl;
	}
 	
system("pause");	
}
