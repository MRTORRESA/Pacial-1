#include <iostream>
using namespace std;
main(){
int num=0;	
cout<<"Ingrese Numero:";
cin>>num;

	if ((num%2)==0){
		cout<<"Par"<<endl;
	}else{
			cout<<"Impar"<<endl;
		}
	
 	
system("pause");	
}
