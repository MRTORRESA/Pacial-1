#include <iostream>
using namespace std;

main(){
	int i=0;
	
	while(i<5){
		//cout<<i<<endl;
		//i=i+1;
		//i+=1;
		i++;
		cout<<i<<endl;
	
	}
	int dec=10;
	cout<<"___________________"<<endl;
	while(dec>0){
		cout<<dec<<endl;
	//dec -=1;
	//dec = dec -1;
		dec--;
	}
	

	
	
system("pause");
}

