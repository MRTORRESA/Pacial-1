#include <iostream>
using namespace std;
main(){
char lapiz,lapicero;
cout<<"Trae Lapiz:";
cin>>lapiz;
cout<<"Trae lapicero:";
cin>>lapicero;

//if (lapiz=='s' && lapicero=='s' )
	if (lapiz=='s' || lapicero=='s' ){
			cout<<lapiz<<endl;
		cout<<"Entra"<<endl;
	}else{
			cout<<"No Entra"<<endl;
		}
	
 	
system("pause");	
}
